import React, { Component, Fragment } from 'react'

export default class Notfound extends Component {
    render() {
        return (
            <Fragment>
                <div className="test vh-100 text-center bg-dark text-white d-flex justify-content-center align-items-center">
                <h1>404 Not Found Component</h1>

                </div>
            </Fragment>
        )
    }
}
