import React, { Component, Fragment } from 'react'

export default class Products extends Component {

    goToProdDetails=(id)=>{
        this.props.history.push("/productDetals/"+id)
    }

    ProdArr = [
        { id: "1", title: "this is a title", prodUrl: "https://www.google.com/" },
        { id: "2", title: "this is a title", prodUrl: "https://www.google.com/" },
        { id: "3", title: "this is a title", prodUrl: "https://www.google.com/" },
        { id: "4", title: "this is a title", prodUrl: "https://www.google.com/" },
        { id: "5", title: "this is a title", prodUrl: "https://www.google.com/" },
        { id: "6", title: "this is a title", prodUrl: "https://www.google.com/" },
    ]

    render() {
        return (
            <Fragment>
                <div className="container my-5 text-center">
                    <div className="row">
                        {this.ProdArr.map((value, index) => {
                            return <div key={index} className="col-md-4">
                                <div onClick={()=>{this.goToProdDetails(value.id)}} className="card p-4 m-3">
                                    <h2>Product Title</h2>
                                    <a href="https://www.google.com">Google</a>
                                </div>
                            </div>
                        })}
                    </div>
                </div>
            </Fragment>
        )
    }
}
