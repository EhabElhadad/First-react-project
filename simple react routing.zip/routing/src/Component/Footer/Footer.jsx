import React, { Component, Fragment } from 'react'

export default class Footer extends Component {
    render() {
        return (
            <Fragment>
                <div className="card bg-dark text-white fixed-bottom">
                    <div className="card-header">
                        Featured
                      </div>

                    <div className="card-body">
                        <h5 className="card-title">Footer Component</h5>
                        <p className="card-text">With supporting text below as a natural lead-in to additional content.</p>
                        <a href="#" className="btn btn-primary">Go somewhere</a>
                    </div>
                </div>
            </Fragment>
        )
    }
}
