import React, { Component, Fragment } from 'react'

export default class ProductDetails extends Component {
    render() {
        console.log(this.props);
        return (
            <Fragment>
                <h1>Product Details</h1>
                <h2>Product Number: {this.props.match.params.id}</h2>
            </Fragment>
        )
    }
}
