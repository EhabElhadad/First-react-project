import React, { Component, Fragment } from 'react'
import { Route, Switch, Redirect } from 'react-router'
import About from './Component/About/About.jsx'
import Contact from './Component/Contact/Contact.jsx'
import Footer from './Component/Footer/Footer.jsx'
import Home from './Component/Home/Home.jsx'
import Navbar from './Component/Navbar/Navbar.jsx'
import Notfound from './Component/Notfound/Notfound.jsx'
import ProductDetails from './Component/ProductDetails/ProductDetails.jsx'
import Products from './Component/Products/Products.jsx'


export default class App extends Component {
  render() {
    return (
      <Fragment>
        <Navbar />
        <Switch>
          <Route exact path="/home" render={(props)=> <Home {...props} x="10"/>} />
          <Route exact path="/about" component={About} />
          <Route exact path="/contact" component={Contact} />
          <Route exact path="/products" component={Products} />
          <Route  path="/productDetals/:id" component={ProductDetails} />
          <Redirect exact from="/" to={Home} />
          <Route path="*" component={Notfound} />

        </Switch>
        <Footer />
      </Fragment>
    )
  }
}
